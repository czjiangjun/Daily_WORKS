import os
import sys
import json
import shutil
import threading
import subprocess
import filetype
import traceback
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5 import QtCore, QtGui, QtWidgets
from pymatgen.io.vasp import Poscar

from ImageWidget import ImageWidget
from MainWindowUI import Ui_MainWindow
from SettingsUI import Ui_Dialog
from WFItemUI import Ui_Form

# 主应用
app = None

# 主界面
myWin = None

# 打开的文件夹路径
rootPath = ''

# 配置项
config = {}


# 任务列表元素UI
class WfItem(QWidget):

    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = Ui_Form()
        self.ui.setupUi(self)
        self.ui.pauseBtn.setIcon(QIcon('icons/pause.png'))
        self.ui.pauseBtn.resize(30, 30)
        self.ui.pauseBtn.setToolTip('暂停任务')
        self.ui.pauseBtn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.ui.cancelBtn.setIcon(QIcon('icons/cancel.png'))
        self.ui.cancelBtn.resize(30, 30)
        self.ui.cancelBtn.setToolTip('取消任务')
        self.ui.cancelBtn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.ui.pauseBtn.clicked.connect(self.pause)
        self.ui.cancelBtn.clicked.connect(self.cancel)

    def setData(self, wf):
        self.id = wf['root_id']
        self.state = wf['state']
        self.wait = False  # 防止重复点击

        self.ui.name.setText(wf['name'])
        self.ui.state.setText(wf['state'])
        self.ui.fw_states.setText(wf['fw_states'])
        self.ui.time.setText(wf['created_on'])

        if self.state == 'PAUSED':
            self.ui.pauseBtn.setIcon(QIcon('icons/resume.png'))
            self.ui.pauseBtn.setToolTip('继续任务')
        elif self.state == 'COMPLETED':
            self.ui.pauseBtn.setEnabled = False
            self.ui.pauseBtn.setToolTip('已完成')
            self.ui.pauseBtn.setCursor(Qt.CursorShape.ForbiddenCursor)
            self.ui.pauseBtn.setIcon(QIcon('icons/finished.png'))
        else:
            self.ui.pauseBtn.setIcon(QIcon('icons/pause.png'))
            self.ui.pauseBtn.setToolTip('暂停任务')

    # 暂停/恢复任务
    @pyqtSlot()
    def pause(self):
        if not self.wait:
            self.wait = True
            if self.state == 'PAUSED':
                myWin.resumeTask(self.id)
            else:
                myWin.pauseTask(self.id)

    # 取消任务
    @pyqtSlot()
    def cancel(self):
        if not self.wait:
            self.wait = True
            myWin.cancelTask(self.id)


# 设置界面UI
class SettingsDialog(QMainWindow, Ui_Dialog):

    def __init__(self, parent=None):
        super(SettingsDialog, self).__init__(parent)
        self.setupUi(self)

        autoSave = bool(config.get('auto_save'))
        disableCheckEnv = bool(config.get('disable_check_env'))
        self.checkboxAutoSave.setChecked(autoSave)
        self.checkBoxDisableCheckEnv.setChecked(disableCheckEnv)

    # 点击确认
    def accept(self):
        config['auto_save'] = self.checkboxAutoSave.isChecked()
        config['disable_check_env'] = self.checkBoxDisableCheckEnv.isChecked()
        self.close()

    # 点击取消
    def reject(self):
        self.close()


# 主界面UI
class MyMainForm(QMainWindow, Ui_MainWindow):

    # 注册槽函数，用于在子线程中更新UI
    addWorkFlowItemSignal = pyqtSignal(dict)

    def __init__(self, parent=None):
        super(MyMainForm, self).__init__(parent)
        self.setupUi(self)
        self.setWindowTitle("客户端")
        self.init = True

        self.initUi()

        # 打开上次的文件夹
        lastPath = config.get('root_path')
        self.OpenRootFolder(lastPath)

        # 每隔20秒自动更新任务列表
        self.timer = QTimer()
        self.timer.timeout.connect(self.updateData)
        self.timer.setInterval(20000)
        self.timer.start()

        # 防止卡顿，在子线程中加载数据库
        threading.Thread(target=self.InitDB).start()

    # 更新任务列表
    def updateData(self):
        if self.init:
            return
        if self.tabWidget_2.currentIndex() == 1:
            self.loadWorkFlows()

    # 增加任务UI
    def addWorkFlowItem(self, wf):
        wfItem = QListWidgetItem()
        wfItem.setSizeHint(QSize(100, 40))
        wfItemWidget = WfItem()
        wfItemWidget.setData(wf)
        self.wfList.addItem(wfItem)
        self.wfList.setItemWidget(wfItem, wfItemWidget)

    # 更新任务UI
    def changeWorkFlowItem(self, wf):
        for i in range(self.wfList.count()):
            child = self.wfList.itemWidget(self.wfList.item(i))
            if child.id == wf['root_id']:
                child.setData(wf)
                break

    # 删除任务UI
    def deleteWorkFlowItem(self, id):
        for i in range(self.wfList.count()):
            child = self.wfList.itemWidget(self.wfList.item(i))
            if child.id == id:
                self.wfList.takeItem(i)
                break

    # 连接数据库和lpad任务管理器
    def InitDB(self):
        self.statusBar.showMessage("加载数据中...")
        from DBConnector import DBConnector
        from QueueManager import QueueManager

        # work flow任务管理器
        self.qm = QueueManager()

        # 连接信号与槽函数，实现子线程中更新数据库UI
        self.addWorkFlowItemSignal.connect(self.addWorkFlowItem)
        try:
            # 数据库
            self.db = DBConnector()
            
            # 加载数据库数据
            self.loadData()

            # 加载认路列表
            self.loadWorkFlows()
            self.statusBar.showMessage("就绪")
            self.init = False
        except:
            traceback.print_exc()
            self.statusBar.showMessage("加载数据失败")

    # UI相关的初始化，包括信号与槽函数的连接，标题与大小的设置等
    def initUi(self):
        self.actionFileOpen.triggered.connect(self.OpenFolder)
        self.actionWindowClose.triggered.connect(self.CloseWindow)
        self.actionSettings.triggered.connect(self.openSettings)
        self.tabWidget.tabCloseRequested.connect(self.CloseFile)

        self.tableWidget.horizontalHeader().setSectionResizeMode(
            QHeaderView.Stretch)
        self.tableWidget.setSelectionBehavior(QTableWidget.SelectRows)
        self.tableWidget.setSelectionMode(QTableWidget.SingleSelection)
        self.tableWidget.itemClicked.connect(self.loadBandStructure)

        self.splitter.setSizes([80, 200])
        self.splitter_2.setSizes([180, 100])
        self.treeWidget.setHeaderLabels(["EXPLORER"])
        self.tabWidget.setTabText(0, "欢迎")
        self.tabWidget_2.setTabText(0, "数据库")
        self.tabWidget_2.setTabText(1, "任务")
        self.tab_1.setProperty("fullpath", '')

        self.treeWidget.setContextMenuPolicy(Qt.CustomContextMenu)
        self.treeWidget.customContextMenuRequested.connect(
            self.showTreeRightMenu)

        self.tableWidget.setContextMenuPolicy(Qt.CustomContextMenu)
        self.tableWidget.customContextMenuRequested.connect(
            self.showTableRightMenu)

        self.wfList.setContextMenuPolicy(Qt.CustomContextMenu)
        self.wfList.customContextMenuRequested.connect(
            self.showWfListRightMenu)

        self.refreshBtn = QPushButton(self)
        self.refreshBtn.setIcon(QIcon('icons/refresh.png'))
        self.refreshBtn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.refreshBtn.setToolTip('刷新')
        self.refreshBtn.setGeometry(self.width() - 60,
                                    self.height() - 60, 30, 30)
        self.refreshBtn.clicked.connect(self.refresh)

        save_shortcut = QShortcut(QKeySequence(Qt.CTRL + Qt.Key_S), self)
        save_shortcut.activated.connect(self.saveText)

    # 更改界面大小时，使刷新按钮处于正确位置
    def resizeEvent(self, event: QtGui.QResizeEvent) -> None:
        self.refreshBtn.move(self.width() - 60, self.height() - 60)
        return super().resizeEvent(event)


    # 刷新数据库或任务列表
    @pyqtSlot()
    def refresh(self):
        if self.init:
            return

        self.statusBar.showMessage("正在刷新...")
        cur = self.tabWidget_2.currentIndex()
        if cur == 0:
            self.loadData()
        elif cur == 1:
            self.loadWorkFlows()
        self.statusBar.showMessage("刷新完成", 2000)


    # 任务列表右键菜单
    def showWfListRightMenu(self, point):
        menu = QMenu(myWin)

        menu.triggered.connect(self.wfListMenuAction)

        a1 = QAction('清空任务列表')
        menu.addAction(a1)

        pos = self.wfList.cursor().pos()
        menu.move(pos)
        menu.show()
        menu.exec()

    # 任务列表右键菜单操作
    def wfListMenuAction(self, action):
        # post to queue
        if action.text() == '清空任务列表':
            btn = QMessageBox.warning(None, '警告', '将取消所有未完成的任务',
                                      QMessageBox.Yes | QMessageBox.No,
                                      QMessageBox.No)
            if btn == QMessageBox.Yes:
                self.qm.resetWorkFlow()
                self.loadWorkFlows()

    # 数据库列表右键菜单
    def showTableRightMenu(self, point):
        menu = QMenu(myWin)

        menu.triggered.connect(self.TableMenuAction)

        a1 = QAction('重新绘图')
        a2 = QAction('删除条目')
        menu.addAction(a1)
        menu.addAction(a2)

        pos = self.tableWidget.cursor().pos()
        menu.move(pos)
        menu.show()
        menu.exec()

    # 数据库列表右键菜单操作
    def TableMenuAction(self, action):
        row = self.tableWidget.currentRow()
        if action.text() == '重新绘图':
            self.loadBandStructure(self.tableWidget.currentItem(), True)
        if action.text() == '删除条目':
            task_id = self.tableWidget.item(row, 2).data(Qt.DisplayRole)
            self.db.dropOne(task_id)
            self.tableWidget.removeRow(row)

    # 文件浏览器右键菜单
    def showTreeRightMenu(self, point):
        menu = QMenu(myWin)

        menu.triggered.connect(self.MenuAction)

        a1 = QAction( "提交到任务队列中")
        menu.addAction(a1)

        pos = self.treeWidget.cursor().pos()
        menu.move(pos)
        menu.show()
        menu.exec()

    # 文件浏览器右键菜单操作
    def MenuAction(self, action):
        items = self.treeWidget.selectedItems()

        if action.text() ==  "提交到任务队列中":
            paths = [i.path for i in items if not i.isDir]

        if not self.init:
            ready, running, failed = self.qm.checkWorkFlow()
            # 存在失败作业
            if failed:
                wfs = self.qm.getBriefWorkFlows()
                wfs_name = ', '.join(
                    [wfs[i]['name'] for i in range(wfs) if i < 5])
                btn = QMessageBox.warning(
                    None, '警告',
                    '任务列表中存在失败的任务，包括以下内容：\n' + wfs_name + '\n将清空任务列表',
                    QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
                if btn == QMessageBox.Yes:
                    self.qm.resetWorkFlow()
                    print('warning: lpad reset!')
                else:
                    return

            # 作业中断（所有任务未启动，处于等待状态）
            if not failed and ready and not running:
                wfs = self.qm.getBriefWorkFlows()
                wfs_name = ', '.join(
                    [wfs[i]['name'] for i in range(len(wfs)) if i < 5])
                btn = QMessageBox.warning(
                    None, '警告',
                    '任务列表中存在未启动的任务，为了避免任务长时间不启动，将清空列表中的任务，包括以下内容：\n' +
                    wfs_name, QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
                if btn == QMessageBox.Yes:
                    self.qm.resetWorkFlow()
                    print('warning: lpad reset!')
                else:
                    return

            yesDataAll = False      # 全部选是
            noDataAll = False       # 全部选否
            yesTaskAll = False  # 全部选是
            noTaskAll = False   # 全部选否
            confirmedFiles = []
            
            # 依次添加任务
            for file in paths:
                poscar = Poscar.from_file(file)
                struct = poscar.structure
                formula = struct.formula

                # 从数据库中查找
                res = self.db.getOneMaterialByFormula(formula)
                if res:
                    # 已存在此化学式数据
                    if noDataAll:
                        continue

                    if yesDataAll:
                        self.db.dropByFormula(formula)
                    else:
                        formula_pretty = res['formula_pretty']
                        btn = QMessageBox.warning(
                            None, '警告', '数据库中存在' + formula_pretty + '数据，是否覆盖？',
                            QMessageBox.Yes | QMessageBox.YesAll
                            | QMessageBox.NoAll | QMessageBox.No
                            | QMessageBox.Cancel, QMessageBox.No)
                        if btn == QMessageBox.Yes:
                            self.db.dropByFormula(formula)
                        elif btn == QMessageBox.YesAll:
                            self.db.dropByFormula(formula)
                            yesDataAll = True
                        elif btn == QMessageBox.No:
                            continue
                        elif btn == QMessageBox.NoAll:
                            noDataAll = True
                            continue
                        elif btn == QMessageBox.Cancel:
                            break
                
                # 从任务列表中查找
                wf = self.qm.findWorkFlowByFormula(formula,
                                                   ignore_completed=True)
                if wf:
                    # 已存在此化学式的任务
                    if noTaskAll:
                        continue

                    if yesTaskAll:
                        self.qm.cancelWorkFlow(wf.root_fw_ids[0])
                    else:
                        btn = QMessageBox.warning(
                            None, '警告', '任务列表中存在' + wf.name + '任务，是否覆盖？',
                            QMessageBox.Yes | QMessageBox.YesAll
                            | QMessageBox.NoAll | QMessageBox.No
                            | QMessageBox.Cancel, QMessageBox.No)
                        if btn == QMessageBox.Yes:
                            self.qm.cancelWorkFlow(wf.root_fw_ids[0])
                        elif btn == QMessageBox.YesAll:
                            self.qm.cancelWorkFlow(wf.root_fw_ids[0])
                            yesTaskAll = True
                        elif btn == QMessageBox.No:
                            continue
                        elif btn == QMessageBox.NoAll:
                            noTaskAll = True
                            continue
                        elif btn == QMessageBox.Cancel:
                            break
                confirmedFiles.append(file)

            # 添加进任务列表中
            self.qm.addWorkFlow(confirmedFiles)

            # 重新加载UI
            self.loadWorkFlows()
            self.loadData()

    # 关闭窗口
    def CloseWindow(self):
        app.quit()


    # 加载数据库数据
    def loadData(self):
        self.tableWidget.clearContents()
        self.tableWidget.setRowCount(0)

        items = self.db.getBriefMaterials()
        keys = ['formula_pretty', 'task_id', 'state', 'completed_at']

        for item in items:
            # 格式化时间
            finishTime: str = item['completed_at']
            idx = finishTime.find('.')
            if idx >= 0:
                finishTime = finishTime[:idx]
            item['completed_at'] = finishTime

            # 添加行
            row = self.tableWidget.rowCount()
            self.tableWidget.insertRow(row)
            i = QTableWidgetItem()
            i.setFlags(i.flags() ^ Qt.ItemIsEditable)   # 只读
            i.setData(Qt.DisplayRole, row + 1)
            self.tableWidget.setItem(row, 0, i)

            # 设置内容
            for j in range(len(keys)):
                i = QTableWidgetItem()
                i.setFlags(i.flags() ^ Qt.ItemIsEditable)

                if type(item[keys[j]]) == int:
                    i.setData(Qt.DisplayRole, item[keys[j]])
                else:
                    i.setText(item[keys[j]])
                self.tableWidget.setItem(row, j + 1, i)

    # 加载任务列表
    def loadWorkFlows(self):
        self.wfList.clear()

        wfs = self.qm.getBriefWorkFlows()
        # 在发送请求到主线程更新UI
        for wf in wfs:
            self.addWorkFlowItemSignal.emit(wf)

    
    # 加载能带结构图
    def loadBandStructure(self, item=None, forced=False):
        if item == None:
            return

        self.statusBar.showMessage("生成图形中...")
        qApp.processEvents()

        formula = self.tableWidget.item(item.row(), 1).text()

        # 缓存文件路径
        cacheFile = rootPath + '/cache/images/' + formula + '.png'

        # 保存文件路径
        savedFile = rootPath + '/images/' + formula + '.png'

        # 判断自动保存是否开启
        autoSave = bool(config.get('auto_save'))
        if autoSave or os.path.exists(savedFile):
            file = savedFile
        else:
            file = cacheFile
        file = os.path.abspath(file)

        # 保存图片
        if not os.path.exists(file) or forced:
            task_id = self.tableWidget.item(item.row(), 2).data(Qt.DisplayRole)
            plot = self.db.getBandStructrueById(task_id)
            plot.savefig(file)

        # 打开图片文件，若之前已打开，则重新打开
        idx = self.findTabByPath(file)
        if idx >= 0:
            self.CloseFile(idx)
        self.OpenFile(file)

        self.statusBar.showMessage("就绪", 2000)

    # 打开选取文件夹界面
    def OpenFolder(self, path=None):
        path = QFileDialog.getExistingDirectory(self, "选取文件夹", "./")
        if path != '':
            self.OpenRootFolder(path)

    # 打开文件夹
    def OpenRootFolder(self, path: str):
        if path == None or not os.path.isdir(path):
            return

        global rootPath
        rootPath = path

        # 创建必要的文件夹
        checkDirectory(rootPath + '/cache')
        checkDirectory(rootPath + '/config')
        checkDirectory(rootPath + '/images')
        checkDirectory(rootPath + '/cache/images')

        # 保存为上次打开的文件夹
        config['root_path'] = path

        # 显示根目录
        self.treeWidget.clear()
        self.treeWidget.setColumnCount(1)
        self.treeWidget.setColumnWidth(0, 50)
        self.treeWidget.setIconSize(QSize(18, 18))
        self.treeWidget.setSelectionMode(QAbstractItemView.ExtendedSelection)

        fileInfo = QFileInfo(rootPath)
        fileIcon = QFileIconProvider()
        icon = QIcon(fileIcon.icon(fileInfo))
        root = QTreeWidgetItem(self.treeWidget)
        root.setText(0, path.split('/')[-1])
        root.setIcon(0, QIcon(icon))
        root.path = rootPath
        root.isDir = True
        QTreeWidgetItem(root)

        # 点击事件
        self.treeWidget.clicked.connect(self.onTreeClicked)
        self.treeWidget.itemExpanded.connect(self.onTreeExpanded)
        QApplication.processEvents()

    # 创建树形结构
    def CreateTree(self, root, path):
        root.takeChildren()

        dirs = []
        files = []
        filesAndDirs = os.listdir(path)
        for i in filesAndDirs:
            path_new = path + '/' + i
            if os.path.isdir(path_new):
                dirs.append((i.lower(), i, path_new))
            else:
                files.append((i.lower(), i, path_new))

        dirs.sort()
        files.sort()

        for _, i, path_new in dirs:
            fileInfo = QFileInfo(path_new)
            fileIcon = QFileIconProvider()
            icon = QIcon(fileIcon.icon(fileInfo))
            child = QTreeWidgetItem(root)
            child.setText(0, i)
            child.setIcon(0, QIcon(icon))
            child.path = path_new
            child.isDir = True
            QTreeWidgetItem(child)
        for _, i, path_new in files:
            fileInfo = QFileInfo(path_new)
            fileIcon = QFileIconProvider()
            icon = QIcon(fileIcon.icon(fileInfo))
            child = QTreeWidgetItem(root)
            child.setText(0, i)
            child.setIcon(0, QIcon(icon))
            child.path = path_new
            child.isDir = False

    # 点击事件
    def onTreeClicked(self, index):
        item = self.treeWidget.itemFromIndex(index)
        if item.isDir:
            # 展开文件夹
            self.treeWidget.setExpanded(index, not item.isExpanded())
        else:
            # 打开文件
            self.OpenFile(item.path)

    # 展开事件
    def onTreeExpanded(self, item):
        # 展开子文件夹
        if item.isDir:
            self.CreateTree(item, item.path)

    # 在打开的标签页里寻找某个文件
    def findTabByPath(self, path):
        for i in range(self.tabWidget.count()):
            t = self.tabWidget.widget(i).property('fullpath')
            if t == path:
                return i
        return -1

    # 在标签页中打开文件
    def OpenFile(self, path):
        i = self.findTabByPath(path)
        if i >= 0:
            # 已经打开了
            self.tabWidget.setCurrentIndex(i)
            return

        tab = self.NewTabWidget(path)
        tab.setProperty('fullpath', path)

        # 新标签页
        idx = self.tabWidget.count()
        self.tabWidget.addTab(tab, path.split('/')[-1])
        self.tabWidget.setCurrentIndex(idx)

    # 关闭标签页
    def CloseFile(self, index):
        # self.tabWidget = QTabWidget()
        self.tabWidget.removeTab(index)

    # 新标签页中的UI布局
    def NewTabWidget(self, path: str) -> QWidget:
        # 判断文件类型
        kind = filetype.guess(path)
        # if kind is None:
        #     print('Cannot guess file type:', path)
        # else:
        #     print('File extension: %s' % kind.extension,
        #           '\tFile MIME type: %s' % kind.mime)

        try:
            if kind and kind.mime == 'image/png':
                # 图片文件
                tab = QWidget()
                sizePolicy = QSizePolicy(QSizePolicy.Expanding,
                                         QSizePolicy.Expanding)
                sizePolicy.setHorizontalStretch(0)
                sizePolicy.setVerticalStretch(0)
                sizePolicy.setHeightForWidth(
                    tab.sizePolicy().hasHeightForWidth())
                tab.setSizePolicy(sizePolicy)

                verticalLayout = QVBoxLayout(tab)
                verticalLayout.setContentsMargins(0, 0, 0, 0)
                verticalLayout.setSpacing(6)
                verticalLayout.setObjectName("verticalLayout")

                imageWidget = ImageWidget(path)
                sizePolicy = QSizePolicy(QSizePolicy.Expanding,
                                         QSizePolicy.Expanding)
                sizePolicy.setHorizontalStretch(0)
                sizePolicy.setVerticalStretch(0)
                sizePolicy.setHeightForWidth(
                    imageWidget.sizePolicy().hasHeightForWidth())
                imageWidget.setSizePolicy(sizePolicy)
                verticalLayout.addWidget(imageWidget)

                saveButton = QPushButton(tab)
                saved = not os.path.abspath(path).startswith(
                    os.path.abspath(rootPath + '/cache/images'))
                if saved:
                    saveButton.setIcon(QIcon('icons/saved.png'))
                    saveButton.setCursor(Qt.ForbiddenCursor)
                    saveButton.setToolTip('图片已保存')
                    saveButton.setCheckable(False)
                else:
                    saveButton.setIcon(QIcon('icons/save.png'))
                    saveButton.setCursor(Qt.PointingHandCursor)
                    saveButton.setToolTip('保存图片')
                    saveButton.setCheckable(True)
                saveButton.setIconSize(QSize(20, 20))
                saveButton.setGeometry(10, 10, 26, 26)

                shareButton = QPushButton(tab)
                shareButton.setIcon(QIcon('icons/share.png'))
                shareButton.setCursor(Qt.PointingHandCursor)
                shareButton.setIconSize(QSize(20, 20))
                shareButton.setGeometry(46, 10, 26, 26)
                shareButton.setToolTip('用其他应用打开')
                shareButton.setCheckable(True)

                saveButton.clicked[bool].connect(self.saveFig)
                shareButton.clicked[bool].connect(self.openWithOther)
            else:
                # 文本文件
                tab = QTextEdit()
                with open(path, 'r') as file:
                    tab.setText(file.read())

        except UnicodeDecodeError:
            tab = QLabel('不支持的文件类型')
            tab.setAlignment(Qt.AlignCenter)
        except:
            traceback.print_exc()
            tab = QLabel('出现未知错误')
            tab.setAlignment(Qt.AlignCenter)
        finally:
            return tab

    # 保存文本文件
    def saveText(self):
        curWidget = self.tabWidget.currentWidget()
        if type(curWidget) == QTextEdit:
            path = curWidget.property('fullpath')
            with open(path, 'w') as f:
                f.write(curWidget.toPlainText())
                self.statusBar.showMessage("保存成功", 2000)

    # 将缓存文件保存为永久文件（images文件夹下）
    def saveFig(self, pressed):
        source = self.sender()
        if pressed:
            i = self.tabWidget.currentIndex()
            item = self.tabWidget.widget(i)
            cache = item.property('fullpath')
            saved = os.path.abspath(rootPath + '/images/' + cache.split('/')[-1])
            shutil.move(cache, saved)
            item.setProperty("fullpath", saved)
            source.setIcon(QIcon('icons/saved.png'))
            source.setCursor(Qt.ForbiddenCursor)
            source.setToolTip('图片已保存')
            source.setCheckable(False)

    # 用其他应用打开
    def openWithOther(self, pressed):
        if pressed:
            i = self.tabWidget.currentIndex()
            item = self.tabWidget.widget(i)
            path = item.property('fullpath')
            subprocess.call(["xdg-open", path])

    # 打开设置界面
    def openSettings(self):
        settings = SettingsDialog(myWin)
        settings.setWindowModality(Qt.ApplicationModal)
        settings.show()

    # 暂停任务
    def pauseTask(self, id):
        self.qm.pauseWorkFlow(id)
        wf = self.qm.getBriefWorkFlowById(id)
        self.changeWorkFlowItem(wf)

    # 恢复任务
    def resumeTask(self, id):
        self.qm.resumeWorkFlow(id)
        wf = self.qm.getBriefWorkFlowById(id)
        self.changeWorkFlowItem(wf)

    # 取消任务
    def cancelTask(self, id):
        self.qm.cancelWorkFlow(id)
        self.deleteWorkFlowItem(id)


# 检查文件夹，不存在则创建
def checkDirectory(path):
    if not os.path.isdir(path):
        if os.path.exists(path):
            btn = QMessageBox.warning(None, '警告', '文件名冲突，将删除' + path + '文件',
                                      QMessageBox.Yes | QMessageBox.No,
                                      QMessageBox.No)
            if btn == QMessageBox.Yes:
                os.remove(path)
                os.mkdir(path)
            else:
                exit(0)
        else:
            os.mkdir(path)


if __name__ == "__main__":

    QCoreApplication.setAttribute(Qt.AA_EnableHighDpiScaling)
    app = QApplication(sys.argv)

    # 配置文件
    CONFIG_FILE = 'config/client.json'

    if not os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, 'w') as f:
            f.write('{}')

    # 加载配置
    with open(CONFIG_FILE, 'r') as f:
        config = json.load(f)

    # 不检查vasp环境，不在本地运行计算程序可能需要勾选此选项
    disableCheckEnv = bool(config.get('disable_check_env'))
    if not disableCheckEnv:
        if not shutil.which('mpiexec'):
            QMessageBox.warning(None, '警告',
                                '未找到mpiexec命令，vasp可能无法执行，请确认环境变量是否正确配置',
                                QMessageBox.Yes, QMessageBox.Yes)

    # 主界面
    myWin = MyMainForm()
    myWin.show()

    # 运行Qt App
    state = app.exec_()

    # 保存当前配置文件
    with open(CONFIG_FILE, 'w') as f:
        json.dump(config, f, sort_keys=True, indent=4, separators=(',', ': '))

    try:
        # 清空缓存文件夹
        shutil.rmtree(rootPath + '/cache/images')
    except:
        pass

    sys.exit(state)
