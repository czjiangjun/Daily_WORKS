from PyQt5.QtWidgets import QWidget
from PyQt5.QtGui import QImage, QPainter, QResizeEvent
from PyQt5.QtCore import Qt, QPoint


# 图片控件（可以缩放和拖动）
class ImageWidget(QWidget):

    def __init__(self, path, parent = None):
        super().__init__(parent)
        # 加载图片
        self.image = QImage(path)
        self.point = QPoint(0, 0)
        self.start_pos = None
        self.end_pos = None
        self.left_click = False
        self.scale = 1
        self.w = 0
        self.h = 0

    def resizeEvent(self, event: QResizeEvent) -> None:
        # 获取窗口的大小
        self.w = event.size().width()
        self.h = event.size().height()
        # 缩放图片，保持纵横比
        self.scaledImage = self.image.scaled(self.w, self.h, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        # 计算图片的位置，使其居中
        self.x = (self.w - self.scaledImage.width()) / 2
        self.y = (self.h - self.scaledImage.height()) / 2
        self.point = QPoint(self.x, self.y)
        self.scale = 1
        # 更新窗口
        self.update()

    def paintEvent(self, e):
        """
        receive paint events
        :param e: QPaintEvent
        :return:
        """
        if self.scaledImage:
            painter = QPainter()
            painter.begin(self)
            # painter.scale(self.scale, self.scale)
            painter.drawImage(self.point, self.scaledImage)
            painter.end()
 
    def wheelEvent(self, event):
        angle = event.angleDelta() / 8  # 返回QPoint对象，为滚轮转过的数值，单位为1/8度
        angleY = angle.y()
        # 获取当前鼠标相对于view的位置
        if angleY > 0:
            factor = 1.2
        else:  # 滚轮下滚
            factor = 0.8
        self.scale *= factor
        self.scaledImage = self.image.scaled(self.w * self.scale, self.h * self.scale, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        self.point = (self.point - event.pos()) * factor + event.pos()
        self.adjustSize()
        self.update()
 
 
    def mouseMoveEvent(self, e):
        """
        mouse move events for the widget
        :param e: QMouseEvent
        :return:
        """
        if self.left_click:
            self.end_pos = e.pos() - self.start_pos
            self.point = self.point + self.end_pos
            self.start_pos = e.pos()
            self.repaint()
 
    def mousePressEvent(self, e):
        """
        mouse press events for the widget
        :param e: QMouseEvent
        :return:
        """
        if e.button() == Qt.LeftButton:
            self.left_click = True
            self.start_pos = e.pos()
 
    def mouseReleaseEvent(self, e):
        """
        mouse release events for the widget
        :param e: QMouseEvent
        :return:
        """
        if e.button() == Qt.LeftButton:
            self.left_click = False