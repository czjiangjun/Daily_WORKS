import json
from atomate.vasp.database import VaspCalcDb
from pymatgen.electronic_structure.plotter import BSPlotter


# 数据库连接管理器
class DBConnector:

    def __init__(self) -> None:
        PATH_TO_MY_DB_JSON = 'config/db.json'
        self.atomate_db = VaspCalcDb.from_db_file(PATH_TO_MY_DB_JSON)
    
    # 依据任务id删除数据
    def dropOne(self, task_id):
        self.atomate_db.collection.find_one_and_delete({
            'task_label': 'nscf line',
            'task_id': task_id
        })
    
    # 依据化学式删除数据
    def dropByFormula(self, formula: str):
        count = self.atomate_db.collection.count_documents({
            'task_label': 'nscf line',
            'orig_inputs.poscar.comment': formula
        })
        for i in range(count):
            self.atomate_db.collection.find_one_and_delete({
                'task_label': 'nscf line',
                'orig_inputs.poscar.comment': formula
            })
    
    # 依据简单化学式获得数据（如MgO）
    def getOneMaterialByFormulaPretty(self, formula: str):
        line_bs_entry = self.atomate_db.collection.find_one({
            'task_label':
            'nscf line',
            'formula_pretty':
            formula
        })
        return line_bs_entry

    # 依据化学式获得数据（如Mg1 O1）
    def getOneMaterialByFormula(self, formula: str):
        line_bs_entry = self.atomate_db.collection.find_one({
            'task_label': 'nscf line',
            'orig_inputs.poscar.comment': formula
        })
        return line_bs_entry

    # 依据任务id获得数据
    def getOneMaterialById(self, task_id: int):
        line_bs_entry = self.atomate_db.collection.find_one({
            'task_label': 'nscf line',
            'task_id': task_id
        })
        return line_bs_entry

    # 绘制能带结构图
    def getBandStructrueById(self, task_id: int):
        bandstructure = self.atomate_db.get_band_structure(task_id)

        bs_plotter = BSPlotter(bandstructure)
        return bs_plotter.get_plot()

    # 获取数据，若提供化学式则获取此数据，或不提供则获取所有数据
    def getMaterials(self, formula=None):
        if formula:
            query = {'task_label': 'nscf line', 'formula_pretty': formula}
        else:
            query = {'task_label': 'nscf line'}

        cursor = self.atomate_db.collection.find(query)
        items = []

        try:
            while True:
                items.append(cursor.next())
        except StopIteration:
            pass

        return items

    # 获取精简后的数据
    def getBriefMaterials(self, formula=None):
        items = []

        for item in self.getMaterials(formula):

            items.append(
                dict([(key, item[key]) for key in
                      ['formula_pretty', 'task_id', 'state', 'completed_at']]))

        return items

    # 保存数据到Json文件
    def dumpToJson(self, item: dict):
        a = item.copy()
        a['_id'] = str(a['_id'])
        a['calcs_reversed'][0]['bandstructure_fs_id'] = str(
            a['calcs_reversed'][0]['bandstructure_fs_id'])
        a['last_updated'] = str(a['last_updated'])
        return json.dumps(a, sort_keys=True, indent=4, separators=(',', ': '))


# 调试
if __name__ == '__main__':
    db = DBConnector()
    formula = 'MgO'
    # item = db.getOneMaterial(formula)
    print(db.getBriefMaterials(formula))
