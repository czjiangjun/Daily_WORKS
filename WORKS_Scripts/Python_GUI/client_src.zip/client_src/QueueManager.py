import getpass
import datetime
import warnings
import subprocess
warnings.filterwarnings('ignore')

from fireworks import LaunchPad
from atomate.vasp.workflows.presets.core import wf_bandstructure
from pymatgen.io.vasp import Poscar

# 任务管理器（基于lpad和squeue）
class QueueManager:

    def __init__(self) -> None:
        self.lpad = LaunchPad.auto_load()
    
    # 获取四个运行状态
    def parseFwStates(self, wf):
        l = [(k, v) for k, v in wf.fw_states.items()]
        l.sort()
        if len(l) >= 4:
            return f'{l[0][1][0]}-{l[1][1][0]}-{l[2][1][0]}-{l[3][1]}'
        else:
            return 'N/A'
    
    # 获取子任务ids，一个计算任务包含4个子任务
    def getWorkFlowIds(self):
        return self.lpad.get_wf_ids()
    
    # 获取所有任务
    def getWorkFlows(self):
        ids = self.getWorkFlowIds()
        wfs = []
        for id in ids:
            wfs.append(self.lpad.get_wf_by_fw_id(id))
        return wfs
    
    # 通过化学式获取任务
    def findWorkFlowByFormula(self, formula: str, ignore_completed = False):
        wfs = self.getWorkFlows()
        for wf in wfs:
            if ignore_completed and wf.state == 'COMPLETED':
                continue
            if wf.metadata['formula'] == formula:
                return wf
        return None
    
    # 通过任务id获取任务信息
    def getWorkFlowById(self, id):
        return self.lpad.get_wf_by_fw_id(id)

    # 通过任务id获取精简后的任务信息
    def getBriefWorkFlowById(self, id):
        wf = self.lpad.get_wf_by_fw_id(id)
        fw_states = self.parseFwStates(wf)
        return {
                'root_id': wf.root_fw_ids[0],
                'name': wf.name,
                'state': wf.state,
                'fw_states': fw_states,
                'created_on': (wf.created_on + datetime.timedelta(hours=8)).strftime("%Y-%m-%d %H:%M:%S")
        }
    
    # 获取精简后的任务列表
    def getBriefWorkFlows(self):
        wfs = self.getWorkFlows()
        bwfs = []
        for wf in wfs:
            fw_states = self.parseFwStates(wf)
            bwfs.append({
                'root_id': wf.root_fw_ids[0],
                'name': wf.name,
                'state': wf.state,
                'fw_states': fw_states,
                'created_on': (wf.created_on + datetime.timedelta(hours=8)).strftime("%Y-%m-%d %H:%M:%S")
            })

        return bwfs

    # 获取正在运行的slurm任务（squeue）
    def getQueue(self):
        res = subprocess.Popen(["squeue"],
                            shell=True,
                            stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE)
        res.stdout.readline()
        tasks = []
        while res.poll() is None:
            task = res.stdout.readline().decode().split()
            if task != None and task != []:
                tasks.append({
                    'id': task[0],
                    'name': task[2],
                    'user': task[3],
                    'state': task[4],
                    'time': task[5]
                })
        return tasks
    
    # 清空任务列表（lpad reset）
    def resetWorkFlow(self):
        self.lpad.reset(datetime.datetime.now().strftime('%Y-%m-%d'))
        subprocess.call(['scancel -n FW_job -u ' + getpass.getuser()],
            shell=True)
        
    # 检查任务运行状态
    def checkWorkFlow(self):
        running = False
        ready = False
        failed = False
        wfs = self.getBriefWorkFlows()
        for wf in wfs:
            state = wf.get('state')
            if state == 'RUNNING':
                running = True
            if state == 'READY':
                ready = True
            if state == 'FIZZLED':
                failed = True
        
        return ready, running, failed
    

    # 添加任务，传入参数为POSCAR文件路径
    def addWorkFlow(self, files):
        if files == None or files == []:
            return

        ready, running, failed = self.checkWorkFlow()
        
        # 未运行任务，取消slurm任务
        if not running:
            subprocess.call(['scancel -n FW_job -u ' + getpass.getuser()],
                shell=True)

        # 添加到work flows任务列表
        for file in files:
            poscar = Poscar.from_file(file)
            struct = poscar.structure
            wf = wf_bandstructure(struct)
            self.lpad.add_wf(wf)

        # 运行新的slurm任务
        if not running:
            res = subprocess.Popen(["qlaunch singleshot"],
                    shell=True,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE)
            while res.poll() is None:
                print(res.stdout.readline().decode())
    
    # 暂停一个任务
    def pauseWorkFlow(self, id):
        self.lpad.pause_wf(id)
    
    # 恢复一个任务
    def resumeWorkFlow(self, id):
        wf = self.getWorkFlowById(id)
        fws = [k for k in wf.fw_states.keys()]
        for i in fws:
            self.lpad.resume_fw(i)
    
    # 取消一个任务
    def cancelWorkFlow(self, id):
        self.lpad.delete_wf(id)
    
    # 取消所有任务
    def cancelAll(self):
        for i in self.lpad.get_wf_ids():
            self.lpad.delete_wf(i)
            

# 调试
if __name__ == '__main__':
    import time

    qm = QueueManager()
    # qm.addWorkFlow('POSCAR/MgO')
    # time.sleep(10)
    # qm.addWorkFlow('POSCAR/MgO')